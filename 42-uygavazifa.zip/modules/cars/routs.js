const {Router}= require("express")
const routCars= Router()
const {carsController}= require("./controller")
routCars.get("/",carsController.getData.bind(carsController) )
routCars.post("/post", carsController.setData.bind(carsController))
routCars.delete("/delet/:id", carsController.deletData.bind(carsController))





module.exports={routCars}